angular.module('opApp', [
    'ngResource',
    'ngSanitize',
    'ngAnimate',
    'ui.bootstrap',
    'opApp.results'
]);